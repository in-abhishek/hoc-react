import React from 'react'

const Mycomponent = ({text}) => {
    return <div>{text}</div>;
}

export default Mycomponent;

